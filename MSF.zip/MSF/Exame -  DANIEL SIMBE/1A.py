import numpy as np
import matplotlib.pyplot as plt

def main():
    # a é a aceleração em m/s^2
    a = np.array([1.617,1.081,0.7807,.05835,.4591,.3605,.3021,.2502,.2093,.1800])
    # r é o raio em 10^^6m
    r = np.array([1.765,2.135,2.482,2.900,3.274,3.636,4.057,4.366,4.826,5.257])
   
    # calcular a regressão linear ()
    data = regressaoLinear(r, a) # [m, b, r^2, deltam, deltab]

    # mostrar o gráfico com os pontos (não é linear)
    plt.plot(r, data[0]*r+data[1]) # reta
    plt.scatter(r, a, color='red') # pontos
    plt.xlabel("r(10^6 m)")
    plt.ylabel("a(m/s^2)")
    plt.show()

    # print m, b, r^2, deltam, deltab
    print("m={}, b={}, r^2={}, deltam={}, deltab={}".format(data[0], data[1], data[2], data[3], data[4]))


def regressaoLinear(x, y):
    n = len(x) 

    sumx = np.sum(x)
    sumy = np.sum(y)
    sumx2 = np.sum(x**2)
    sumy2 = np.sum(y**2)
    sumxy = np.sum(np.multiply(x, y))

    # calcular m, b, r^2, dm, db

    m = (n*sumxy - sumx*sumy)/(n*sumx2 - sumx**2)
    b = (sumx2*sumy - sumx*sumxy)/(n*sumx2 - sumx**2)
    r2 = (n*sumxy - sumx*sumy)**2/((n*sumx2 - sumx**2)*(n*sumy2 - sumy**2))
    dm = np.abs(m)*np.sqrt(((1/r2)-1)/(n-2))
    db = dm*np.sqrt(sumx2/n)

    return m, b, r2, dm, db

main()