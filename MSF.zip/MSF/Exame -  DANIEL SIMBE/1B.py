import numpy as np
import matplotlib.pyplot as plt

def main():
    # x é o tempo em segundos(t)
    x = np.array([0.5, 1.5, 2.5, 3.5, 4.5, 5.5, 6.5, 7.5, 8.5, 9.5, 10.5])
    # y é o percurso percorrido(s)
    y = np.array([0.1, 1.4, 1.7, 6.5, 7.7, 10.4, 19.5, 26.1, 26.5, 45.9, 52.5])
    # transformar em log(x) e log(y)
    logx = np.log(x)
    logy = np.log(y)


    # calcular a regressão linear ()
    data = regressaoLinear(logx, logy) # [m, b, r^2, deltam, deltab]

    # mostrar o gráfico com os pontos (não é linear)
    plt.plot(logx, data[0]*logx+data[1]) # reta
    plt.scatter(logx, logy, color='red') # pontos
    plt.xlabel("t(s)")
    plt.ylabel("x(m)")
    plt.show()

     


    # print m, b, r^2, deltam, deltab
    print("m={}, b={}, r^2={}, deltam={}, deltab={}".format(data[0], data[1], data[2], data[3], data[4]))


def regressaoLinear(x, y):
    n = len(x) 

    sumx = np.sum(x)
    sumy = np.sum(y)
    sumx2 = np.sum(x**2)
    sumy2 = np.sum(y**2)
    sumxy = np.sum(np.multiply(x, y))

    # calcular m, b, r^2, dm, db

    m = (n*sumxy - sumx*sumy)/(n*sumx2 - sumx**2)
    b = (sumx2*sumy - sumx*sumxy)/(n*sumx2 - sumx**2)
    r2 = (n*sumxy - sumx*sumy)**2/((n*sumx2 - sumx**2)*(n*sumy2 - sumy**2))
    dm = np.abs(m)*np.sqrt(((1/r2)-1)/(n-2))
    db = dm*np.sqrt(sumx2/n)

    return m, b, r2, dm, db

main()