import numpy as np
import matplotlib.pyplot as plt


P = 283 * 735.4975
vi = 1 #velocidade inicial
m = 1500
Cres = 0.9
energia= P*3*3600
print(energia," J")
A = 1.8*1.3 #Área frontal m**2
p = 1.225
u = 0.9#coef de resistencia
g = 9.8

ti = 0
tf = 3600*3 #3horas
dt = 0.01

n = int((tf-ti)/dt)


x = np.empty(n+1)
x[0] = 0

vx = np.empty(n+1)
vx[0] = vi

v = np.empty(n+1)
v[0] = vi

ax = np.empty(n+1)
ax[0] = 0
t = np.empty(n+1)
t[0]= 0

for i in range(n):

    t[i+1] = t[i] + dt
    v[i] = np.sqrt(vx[i]**2)
    
    ax[i] = -u*g - (Cres/(2*m))*A*p*v[i]*vx[i] + (P/(m*v[i]))
    
    vx[i+1] = vx[i] + ax[i]*dt
    
    x[i+1] = x[i] + vx[i]*dt 

dist = x[n]
vterminal = vx[n]
print("A distância em metros é : ", dist)
print("Velocidade em 3h  : ", vterminal)

plt.plot(t, x, color="blue")
plt.xlabel("Tempo(s)")
plt.ylabel("Distância (m)")
plt.show()
plt.grid()