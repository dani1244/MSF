# impulso de uma força slide 21/30 tp8
""" Problema:
Se 𝑚 = 0.057
v0 = -30 i km/h
v1 = 30 i km/h
Qual a força média do impacto que durou 0.06 s? """

m= 0.057
v0x = -30/3.6
vx = 30/3.6

f = (m*vx - m*v0x)/0.06

print(f)

# Outro problema:
# aibarg aumenta o tempo de contato e diminui proporcionalmente (ambos são inv prop) a força feita na pessoa. por isso é mais seguro